var userData, userInfo;
var esbapitoken = window.parent.staticData.apiPaths.search.esbApiToken;


$(document).ready(function() {
    getUserSummary(userData).then(function(response) {

        userInfo = response;

        $('#userDetails .user-name').empty().append('<h3>Name: ' + userInfo.firstName + ' ' + userInfo.lastName + '</h3>');
        $('#userDetails .user-jobTitle').empty().append('<h3>Job Title: ' + userInfo.jobTitle + '</h3>');

        //     getBannerData();
        //     getImportantLinksData();
        //     getTrainingMetrics();
        //     getAssignedTrainingChart();
        //     getUpcomingILTData();

        //     readTimelineAPI();
    })

})


function getUserSummary(userData) {
    return $.ajax({
        "url": protocol + hostName + "/apis/api/v1/users/summary",
        "method": "GET",
        "timeout": 0,
        "cache": true,
        "headers": {
            "sumtauth-header": esbapitoken,
        },
        success: function(response) {
            userData = response;
            console.log(userData);
        },
        error: function(msg) {
            console.log('error: ' + msg);
        }
    });
}